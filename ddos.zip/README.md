git clone https://github.com/HUNTERKINGCY78/DDOS_JS_TELE

cd DDOS_JS_TELE

bash DDOS
